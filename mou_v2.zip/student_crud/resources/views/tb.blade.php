<!DOCTYPE html>
<html lang="en">
<head>
  <title>view</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>

  <div class="container">
	<div class="row">
        <div class="col-md-9">
    		<h2>ค้นหาตาราง</h2>
            <div id="custom-search-input">
            <form action="select_std.php" method="get">
              <select class="form-control" name="mj">
                <option value="" selected="">Human Resources</option>
                <option value="G01(1)">Room</option>
              </select>
                <div class="input-group col-md-12">
                    <input type="text" class="form-control input-lg" placeholder="ป้อนรหัส หรือ ชื่อนิสิต" name="Search">
                    <span class="input-group-btn">
                      <!-- <button class="btn btn-outline-success my-2 my-sm-0" type="submit" name="btnGetJson" id="btnGetJson">search</button> -->
                        <button class="btn btn-info btn-lg" type="submit">
                            ...<i class="icon-search"></i>
                        </button>
                    </span>

                </div>
			        </form>
            </div>
        </div>
	</div>
</div>

<div class="container">
  <table class="table table-bordered">
    <br>
    <thead>
      <tr>
        <th>idhr</th>
        <th>name</th>
        <th>pos</th>
        <th>access_lv</th>
        <th>gmail</th>
        <th>address</th>
        <th>pass</th>
        <th>provider_id</th>
      </tr>
    </thead>
    <tbody>
        <?php
          echo App\Http\Controllers\Controller::getData();
        ?>
      </span>
    </tbody>
  </table>
</div>

</body>
</html>
