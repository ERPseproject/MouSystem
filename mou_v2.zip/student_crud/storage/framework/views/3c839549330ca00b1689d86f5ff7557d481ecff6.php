<!DOCTYPE html>
<html lang="en">

<head>
    <title>Bootstrap Example</title>
    <meta charset="utf-8">
    <link href="<?php echo e(asset('css/index.css')); ?>" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

    <script language="javascript">
      function show_table(id) {
        if(id == 'MOU') { // ถ้าเลือก radio button 1 ให้โชว์ table 1 และ ซ่อน table 2
          document.getElementById("a").style.display = "";
          document.getElementById("b").style.display = "";
          document.getElementById("c").style.display = "";
          document.getElementById("d").style.display = "";
          document.getElementById("e").style.display = "";
        } else if(id == 'Open') { // ถ้าเลือก radio button 2 ให้โชว์ table 2 และ ซ่อน table 1
          document.getElementById("a").style.display = "none";
          document.getElementById("b").style.display = "none";
          document.getElementById("c").style.display = "none";
          document.getElementById("d").style.display = "none";
          document.getElementById("e").style.display = "none";
        }
      }
    </script>
</head>

<header>
<body>

    <!-- nav bar -->
    <nav class="navbar navbar-inverse navbar-fixed-top" style="background-color: #8B0000;">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">Logo Web</a>
            </div>
            <div class="collapse navbar-collapse" id="myNavbar">
                <ul class="nav navbar-nav">
                    <li class="active"><a href="#">Home</a></li>

                </ul>
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#"><span class="glyphicon glyphicon-log-in"></span> Login</a></li>
                </ul>
            </div>
        </div>
    </nav>


    <div class="main">
        <div class="container-fluid ">
            <div class="row content">
                <div class="col-sm-2 sidenav">
                  <h2 class="w3-bar-item"><b>Menu</b></h2>
                  <h4><a class="w3-bar-item w3-button w3-hover-black" href="moufirst.html">หน้าแรกระบบ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="mouIn.html">เพิ่มโครงการพัฒนาวิชาการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="customer.html">เพิ่มข้อมูลผู้รับบริการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="#">ค้นหาข้อมูลโครงการพัฒนาวิชาการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="#">ค้นหาข้อมูลโครงการบริการ</a><br><br>
                  <a class="w3-bar-item w3-button w3-hover-black" href="recipe.html">การบันทึกใบเสร็จ</a><br></h4>
                </div>



                <div class="col-sm-8">
                  <div class="w3-row w3-padding-64">
                    <div class="w3-twothird w3-container">
                      <h1 class="w3-text-teal">เพิ่มข้อมูลโครงการพัฒนาวิชาการ</h1>
                      <div class="form-group">
                        <label for="usr">ชื่อโครงการ:</label>
                        <input type="text" class="form-control">
                      </div>

                      <div class="form-inline">
                        <label for="sel1">หัวหน้าโครงการ):</label>
                        <select class="form-control">
                          <option>นายกอ</option>
                          <option>นางขอ</option>
                          <option>นางมอ</option>
                          <option>นางสาววจก</option>
                          <option>-</option>
                        </select>
                        <label for="sel1">ชื่อผู้รับผิดชอบ2:</label>
                        <select class="form-control" >
                          <option>นายกอ</option>
                          <option>นางขอ</option>
                          <option>นางมอ</option>
                          <option>นางสาววจก</option>
                            <option>-</option>
                        </select>
                        <label for="sel1">ชื่อผู้รับผิดชอบ3:</label>
                        <select class="form-control">
                          <option>นายกอ</option>
                          <option>นางขอ</option>
                          <option>นางมอ</option>
                          <option>นางสาววจก</option>
                            <option>-</option>
                        </select>
                        <label for="sel1">ชื่อผู้รับผิดชอบ4:</label>
                        <select class="form-control">
                          <option>นายกอ</option>
                          <option>นางขอ</option>
                          <option>นางมอ</option>
                          <option>นางสาววจก</option>
                            <option>-</option>
                        </select>
                      </div>
                      <br>
                      <div class="form-group">
                        <label for="usr">เลขกำกับโครงการ:</label>
                        <input type="text" class="form-control" >
                      </div>



                      <div class="radio" >
                        <label><input value="MOU" type="radio" name="optradio" onclick="show_table(this.value);" checked="checked">MOU</label>
                        <label><input value="Open" type="radio" name="optradio" onclick="show_table(this.value);">Open</label>
                      </div><br>
                      <div class="form-group" id='a'>
                        <label for="sel1">ผู้รับบริการ:</label>
                        <select class="form-control" id="customer">
                          <option>นายJack</option>
                          <option>นางRose</option>
                          <option>นางSuzie</option>
                          <option>นางสาวBatman</option>
                        </select>
                      </div>

                      <div class="form-group" id='b'>
                        <label for="pwd">งบประมาณ:</label>
                        <input type="text" class="form-control">
                      </div>

                      <div class="form-group" id='c'>
                        <!-- <form action="upload.php" method="post" enctype="multipart/form-data"> -->
                      <b>อัพโหลดไฟล์เอกสาร:</b>
                        <input type="file" name="fileToUpload" id="fileToUpload"><br>
                      <!-- </form> -->
                      </div>

                      <form class="form-inline"  id='d'>
                        <div class="form-group">
                          <label >วันเปิดโครงการ:</label>
                          <input type="text" class="form-control" >&nbsp;&nbsp;
                        </div>
                        <div class="form-group">
                          <label>วันปิดโครงการ:</label>
                          <input type="text" class="form-control" >&nbsp;
                        </div>
                      </form><br>
                      <div class="form-group" id='e'>
                        <label>ปีงบประมาณ:</label>
                        <input type="text" class="form-control" >
                      </div>

                      <input type="submit" value="submit" class="btn btn-default">
                    </div>
                  </div>
                </div>
                <div class="col-sm-2 sidenav"></div>
            </div>
        </div>
    </div>

        <footer class="container-fluid text-center">
  <p>Footer Text</p>
</footer>

</body>
</header>
</html>
