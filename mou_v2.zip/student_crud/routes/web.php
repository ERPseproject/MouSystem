<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
// Route::get('/table', function () {
//     return view('tb');
// });
// Route::post('/table', 'Controller@getData'
// );


//start from here
Route::get('/moufirst', function () {
    return view('mou.moufirst');
});


Route::get('/mou/customer', function () {
    return view('mou.customers.createcus');
});

// Route::get('/mou/recipe', function () {
//     return view('mou.recipes.recipe');
// });



Route::get('/mou/mouIn', 'PjsController@index')->name('mouIn');
Route::post('/storemou','PjsController@store');

// Route::post('/mou/mouIn/store', 'PjsController@store')->name('store');




Route::get('/recipe','RecipeController@index');
Route::post('/addimage','RecipeController@store')->name('addimage');
// Route::post('/getpcus', 'RecipeController@getpcus')->name('getpcus');



Route::resource('/mou/mouIn','PjsController');
Route::resource('/mou', 'MouController'); //customer
Route::resource('/mou/recipes', 'RecipeController');


